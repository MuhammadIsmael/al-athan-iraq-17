package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import com.alathaniraq.tv.databinding.ActivityHomeScreenPickerBinding
import com.alathaniraq.tv.util.Prefs

class HomeScreenPickerActivity : BaseActivity() {

    private lateinit var binding: ActivityHomeScreenPickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeScreenPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.optionDashboard.setOnClickListener { choose(Prefs.HOME_MODE_DASHBOARD) }
        binding.optionAnalog.setOnClickListener { choose(Prefs.HOME_MODE_ANALOG) }
        binding.optionClassic.setOnClickListener { choose(Prefs.HOME_MODE_CLASSIC) }

        val current = Prefs.getHomeScreenMode(this)
        when (current) {
            Prefs.HOME_MODE_CLASSIC -> binding.optionClassic.requestFocus()
            Prefs.HOME_MODE_ANALOG -> binding.optionAnalog.requestFocus()
            else -> binding.optionDashboard.requestFocus()
        }
    }

    private fun choose(mode: String) {
        Prefs.setHomeScreenMode(this, mode)
        setResult(Activity.RESULT_OK)
        finish()
    }
}
