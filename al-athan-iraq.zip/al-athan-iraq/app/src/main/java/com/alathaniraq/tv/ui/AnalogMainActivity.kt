package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.alathaniraq.tv.R
import com.alathaniraq.tv.data.IraqRegions
import com.alathaniraq.tv.data.PrayerTimesRepository
import com.alathaniraq.tv.data.Timings
import com.alathaniraq.tv.databinding.ActivityMainAnalogBinding
import com.alathaniraq.tv.databinding.ItemPrayerCardDashboardBinding
import com.alathaniraq.tv.util.AthanScheduler
import com.alathaniraq.tv.util.DateFormatting
import com.alathaniraq.tv.util.NetworkStatus
import com.alathaniraq.tv.util.Prefs
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * The "Analog" home screen design: an analog clock face (custom-drawn in
 * AnalogClockView) with the date curved along its rim, in place of the Dashboard's
 * digital clock box. Everything else — header, online status, next-prayer countdown,
 * prayer cards, branding — follows the same pattern as DashboardMainActivity, just
 * without the Shuruk/Jumua side blocks (not part of this design's reference image).
 */
class AnalogMainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainAnalogBinding
    private val repository = PrayerTimesRepository()
    private val handler = Handler(Looper.getMainLooper())
    private var currentTimings: Timings? = null
    private var timingsDayOfYear: Int = -1
    private var tomorrowFajr: String? = null
    private var tomorrowFajrRequestInFlight = false
    private var currentLocation: IraqRegions.ResolvedLocation =
        IraqRegions.resolveLocation(IraqRegions.defaultDistrict().id, null)
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val tickRunnable = object : Runnable {
        override fun run() {
            binding.analogClock.invalidate()
            updateCountdown()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainAnalogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuButton.setOnClickListener {
            startActivityForResult(Intent(this, MenuActivity::class.java), REQUEST_MENU)
        }
        // Explicit initial D-pad focus for TV/TV-box remotes.
        binding.menuButton.requestFocus()

        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MENU && resultCode == Activity.RESULT_OK) {
            val target = HomeScreenRouter.launcherActivityClass(this)
            if (target != AnalogMainActivity::class.java) {
                // User switched to a different design in Settings — hand off to it.
                startActivity(Intent(this, target))
                finish()
            } else {
                // Same reasoning as DashboardMainActivity: a full recreate() is needed
                // (not just refresh()) so a language change re-inflates static labels.
                recreate()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tickRunnable)
        updateOnlineStatus()
        networkCallback = NetworkStatus.registerCallback(this) { online ->
            runOnUiThread { setOnlineStatus(online) }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
        NetworkStatus.unregister(this, networkCallback)
        networkCallback = null
    }

    private fun updateOnlineStatus() {
        setOnlineStatus(NetworkStatus.isOnline(this))
    }

    private fun setOnlineStatus(online: Boolean) {
        val color = if (online) {
            ContextCompat.getColor(this, R.color.gold_accent)
        } else {
            ContextCompat.getColor(this, R.color.status_offline_red)
        }
        binding.statusDot.setColorFilter(color)
        binding.statusText.text = getString(if (online) R.string.online else R.string.offline)
    }

    private fun refresh() {
        currentLocation = IraqRegions.resolveLocation(Prefs.getDistrictId(this), Prefs.getSubDistrictId(this))
        binding.headerTitle.text = "${Prefs.getMosqueName(this)} – ${currentLocation.displayName}"
        applyColorScheme()

        lifecycleScope.launch {
            val result = repository.fetchToday(currentLocation.latitude, currentLocation.longitude)
            result.onSuccess { data ->
                currentTimings = data.timings
                timingsDayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                tomorrowFajr = null
                tomorrowFajrRequestInFlight = false
                binding.analogClock.dateText = DateFormatting.dashboardDateLine(data.date.hijri)

                bindPrayerCard(binding.cardFajr, getString(R.string.fajr), data.timings.fajr)
                bindPrayerCard(binding.cardDhuhr, getString(R.string.dhuhr), data.timings.dhuhr)
                bindPrayerCard(binding.cardAsr, getString(R.string.asr), data.timings.asr)
                bindPrayerCard(binding.cardMaghrib, getString(R.string.maghrib), data.timings.maghrib)
                bindPrayerCard(binding.cardIsha, getString(R.string.isha), data.timings.isha)

                updateCountdown()
                AthanScheduler.scheduleToday(this@AnalogMainActivity, data.timings)
            }.onFailure {
                binding.countdown.text = getString(R.string.error_loading)
            }
        }
    }

    /** Applies the user's chosen color scheme (Settings > Color Scheme). Ring, numerals,
     *  date text, and the second hand follow the scheme's accent/primary text colors —
     *  the teal face and black hour/minute hands stay as designed, same principle as
     *  Dashboard leaving card fills and borders untouched. */
    private fun applyColorScheme() {
        val scheme = ColorSchemes.current(this)
        binding.root.setBackgroundColor(scheme.background)
        binding.headerTitle.setTextColor(scheme.primaryText)
        binding.nextPrayerLabel.setTextColor(scheme.primaryText)
        binding.countdown.setTextColor(scheme.accentText)
        binding.analogClock.ringColor = scheme.accentText
        binding.analogClock.numeralColor = scheme.primaryText
        binding.analogClock.dateTextColor = scheme.primaryText
        binding.analogClock.secondHandColor = scheme.accentText
        listOf(binding.cardFajr, binding.cardDhuhr, binding.cardAsr, binding.cardMaghrib, binding.cardIsha).forEach {
            it.prayerName.setTextColor(scheme.primaryText)
            it.prayerTime.setTextColor(scheme.accentText)
        }
    }

    private fun bindPrayerCard(
        cardBinding: ItemPrayerCardDashboardBinding,
        name: String,
        time: String
    ) {
        cardBinding.prayerName.text = name
        cardBinding.prayerTime.text = DateFormatting.withSmallAmPm(DateFormatting.to12Hour(time))
    }

    /** Finds the next upcoming prayer and updates the countdown + card highlighting.
     *  Same logic as DashboardMainActivity — see there for the day-rollover and
     *  post-Isha tomorrow's-Fajr details. */
    private fun updateCountdown() {
        val now = Calendar.getInstance()

        if (timingsDayOfYear != -1 && now.get(Calendar.DAY_OF_YEAR) != timingsDayOfYear) {
            refresh()
            return
        }

        val timings = currentTimings ?: return
        val order = listOf(
            getString(R.string.fajr) to timings.fajr,
            getString(R.string.dhuhr) to timings.dhuhr,
            getString(R.string.asr) to timings.asr,
            getString(R.string.maghrib) to timings.maghrib,
            getString(R.string.isha) to timings.isha
        )

        var nextIndex = -1
        var nextMillis = Long.MAX_VALUE

        order.forEachIndexed { index, (_, time) ->
            val parts = time.take(5).split(":")
            if (parts.size != 2) return@forEachIndexed
            val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
            val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            if (target.after(now) && target.timeInMillis < nextMillis) {
                nextMillis = target.timeInMillis
                nextIndex = index
            }
        }

        val cards = listOf(binding.cardFajr, binding.cardDhuhr, binding.cardAsr, binding.cardMaghrib, binding.cardIsha)

        if (nextIndex == -1) {
            binding.nextPrayerLabel.text = getString(R.string.next_prayer_in, getString(R.string.fajr))
            cards.forEachIndexed { index, card ->
                card.root.setBackgroundResource(
                    if (index == 0) R.drawable.card_background_highlight else R.drawable.card_background
                )
            }

            val fajrTomorrow = tomorrowFajr
            if (fajrTomorrow == null) {
                loadTomorrowFajr()
                binding.countdown.text = "--:--:--"
                return
            }

            val parts = fajrTomorrow.take(5).split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull()
            val minute = parts.getOrNull(1)?.toIntOrNull()
            if (hour == null || minute == null) {
                binding.countdown.text = "--:--:--"
                return
            }
            val target = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            val diff = (target.timeInMillis - now.timeInMillis) / 1000
            if (diff < 0) {
                binding.countdown.text = "--:--:--"
                return
            }
            binding.countdown.text = formatCountdown(diff)
            return
        }

        cards.forEachIndexed { index, card ->
            card.root.setBackgroundResource(
                if (index == nextIndex) R.drawable.card_background_highlight else R.drawable.card_background
            )
        }

        binding.nextPrayerLabel.text = getString(R.string.next_prayer_in, order[nextIndex].first)

        val diff = (nextMillis - now.timeInMillis) / 1000
        binding.countdown.text = formatCountdown(diff)
    }

    private fun formatCountdown(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return String.format(DateFormatting.WESTERN_DIGITS, "%02d:%02d:%02d", h, m, s)
    }

    private fun loadTomorrowFajr() {
        if (tomorrowFajrRequestInFlight) return
        tomorrowFajrRequestInFlight = true
        val tomorrowTimestamp = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis / 1000
        lifecycleScope.launch {
            val result = repository.fetchForTimestamp(currentLocation.latitude, currentLocation.longitude, tomorrowTimestamp)
            result.onSuccess { data -> tomorrowFajr = data.timings.fajr }
            tomorrowFajrRequestInFlight = false
        }
    }

    companion object {
        private const val REQUEST_MENU = 200
    }
}
