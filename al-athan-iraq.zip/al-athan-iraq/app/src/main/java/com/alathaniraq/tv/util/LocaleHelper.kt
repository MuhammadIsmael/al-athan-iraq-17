package com.alathaniraq.tv.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {

    /** Returns a new Context configured for the user's chosen app language. Uses
     *  forLanguageTag rather than the Locale(lang) constructor so 3-letter codes
     *  (e.g. "ckb" for Kurdish Sorani) resolve correctly to their matching
     *  values-b+xxx resource qualifier folder, not just 2-letter ones.
     *
     *  Deliberately does NOT call Locale.setDefault() — that would change the JVM-wide
     *  default locale, which silently flips any number/date formatting elsewhere that
     *  doesn't pass an explicit Locale (e.g. Arabic locale defaults to Eastern Arabic
     *  numerals ٠١٢...). Only this Context's Configuration is localized, so translated
     *  strings load correctly while all of the app's own number formatting — which
     *  already explicitly requests Locale.ENGLISH — keeps producing plain 0-9 digits. */
    fun wrap(context: Context): Context {
        val languageCode = Prefs.getAppLanguage(context)
        val locale = Locale.forLanguageTag(languageCode)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        return context.createConfigurationContext(config)
    }
}
