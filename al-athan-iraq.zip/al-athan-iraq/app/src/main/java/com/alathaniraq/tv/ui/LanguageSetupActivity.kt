package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import com.alathaniraq.tv.databinding.ActivityLanguageSetupBinding
import com.alathaniraq.tv.util.Prefs

/**
 * Doubles as both the first screen of first-launch setup AND the "Change Language"
 * screen reachable from Settings later (see MenuActivity). Which mode it's in is
 * decided by EXTRA_FROM_SETTINGS:
 * - First-launch (extra absent/false): "Next" saves the language and continues to
 *   OrientationSetupActivity, same as before.
 * - From Settings (extra true): the button reads "Done", saves the language, and
 *   returns RESULT_OK to the caller (which should recreate() to reload strings)
 *   instead of continuing the onboarding chain.
 *
 * Selection highlight color follows whatever the app's current color scheme accent is
 * (Settings > Color Scheme — defaults to gold), rather than a hardcoded color, so this
 * stays visually consistent with the rest of the app either way.
 */
class LanguageSetupActivity : BaseActivity() {

    private lateinit var binding: ActivityLanguageSetupBinding
    private var selected: String = Prefs.LANGUAGE_ENGLISH
    private var fromSettings: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fromSettings = intent.getBooleanExtra(EXTRA_FROM_SETTINGS, false)
        if (fromSettings) {
            binding.nextButton.setText(com.alathaniraq.tv.R.string.done)
        }

        selected = Prefs.getAppLanguage(this)

        binding.optionEnglish.setOnClickListener { select(Prefs.LANGUAGE_ENGLISH) }
        binding.optionArabic.setOnClickListener { select(Prefs.LANGUAGE_ARABIC) }
        binding.optionKurdish.setOnClickListener { select(Prefs.LANGUAGE_KURDISH_SORANI) }
        // Explicit initial D-pad focus for TV/TV-box remotes — matters especially here
        // since this can be the very first screen a person sees on first launch.
        binding.optionEnglish.requestFocus()

        binding.nextButton.setOnClickListener {
            Prefs.setAppLanguage(this, selected)
            if (fromSettings) {
                setResult(Activity.RESULT_OK)
                finish()
            } else {
                startActivity(Intent(this, OrientationSetupActivity::class.java))
                // Recreate isn't needed here — OrientationSetupActivity's attachBaseContext
                // picks up the just-saved language fresh when it's created.
                finish()
            }
        }

        refreshSelection()
    }

    private fun select(language: String) {
        selected = language
        refreshSelection()
    }

    private fun refreshSelection() {
        val accent = ColorSchemes.current(this).accentText
        highlight(binding.optionEnglish, selected == Prefs.LANGUAGE_ENGLISH, accent)
        highlight(binding.optionArabic, selected == Prefs.LANGUAGE_ARABIC, accent)
        highlight(binding.optionKurdish, selected == Prefs.LANGUAGE_KURDISH_SORANI, accent)
    }

    private fun highlight(button: Button, isSelected: Boolean, accent: Int) {
        OnboardingUi.highlight(this, button, isSelected, accent)
    }

    companion object {
        const val EXTRA_FROM_SETTINGS = "from_settings"
    }
}
