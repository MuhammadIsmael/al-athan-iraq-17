package com.alathaniraq.tv.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.alathaniraq.tv.util.Prefs

/**
 * Shows the branded startup screen (res/drawable-nodpi/splash_screen.png, set as this
 * activity's window background via Theme.AlAthanIraq.Splash) for a short delay, then
 * hands off either to first-launch setup (language + orientation, shown once) or
 * straight to whichever home screen design is currently selected (see
 * HomeScreenRouter / Settings > Change Home Screen). No layout is inflated here — the
 * image IS the window background, so there's zero flicker between window-draw and
 * content-draw.
 */
class SplashActivity : BaseActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val goToNext = Runnable {
        val next = if (Prefs.isOnboardingComplete(this)) {
            HomeScreenRouter.launcherActivityClass(this)
        } else {
            LanguageSetupActivity::class.java
        }
        startActivity(Intent(this, next))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handler.postDelayed(goToNext, SPLASH_DURATION_MS)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(goToNext)
    }

    companion object {
        private const val SPLASH_DURATION_MS = 2000L
    }
}
