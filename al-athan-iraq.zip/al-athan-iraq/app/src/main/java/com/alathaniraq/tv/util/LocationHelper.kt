package com.alathaniraq.tv.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Uses the platform LocationManager directly (no Google Play Services dependency)
 * to find the device's approximate location for the "Use My Location" option in
 * the district picker. TVs typically have no location hardware at all — every
 * entry point here fails gracefully (calls back with null) rather than crashing,
 * so the manual governorate/district picker always remains available as a fallback.
 */
object LocationHelper {

    fun hasPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        return fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Tries a cached last-known location first (instant, but may be stale or absent),
     * then falls back to a single fresh GPS/network fix with a timeout. Calls
     * [onResult] exactly once, on the main thread, with null if location couldn't be
     * determined for any reason (no permission, no provider, timeout, disabled GPS).
     */
    @SuppressLint("MissingPermission")
    fun getCurrentLocation(context: Context, timeoutMs: Long = 12_000L, onResult: (Location?) -> Unit) {
        if (!hasPermission(context)) {
            onResult(null)
            return
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm == null) {
            onResult(null)
            return
        }

        val cached = bestLastKnown(lm)
        if (cached != null) {
            onResult(cached)
            return
        }

        val provider = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            onResult(null)
            return
        }

        var delivered = false
        val handler = Handler(Looper.getMainLooper())
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (delivered) return
                delivered = true
                try { lm.removeUpdates(this) } catch (_: Exception) {}
                onResult(location)
            }

            @Deprecated("Deprecated in platform API, override required pre-API 29")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

            override fun onProviderEnabled(provider: String) {}

            override fun onProviderDisabled(provider: String) {
                if (delivered) return
                delivered = true
                onResult(null)
            }
        }

        try {
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            onResult(null)
            return
        }

        handler.postDelayed({
            if (!delivered) {
                delivered = true
                try { lm.removeUpdates(listener) } catch (_: Exception) {}
                onResult(null)
            }
        }, timeoutMs)
    }

    private fun bestLastKnown(lm: LocationManager): Location? {
        var best: Location? = null
        for (provider in lm.allProviders) {
            val loc = try {
                lm.getLastKnownLocation(provider)
            } catch (e: SecurityException) {
                null
            } ?: continue
            if (best == null || loc.accuracy < best.accuracy) best = loc
        }
        return best
    }
}
